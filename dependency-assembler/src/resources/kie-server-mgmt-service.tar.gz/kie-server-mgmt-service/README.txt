
Sample kjar:

com.rhc:test:1448602158560
test-1448602158560.jar


Sample Decision Server Requests:

--- Request Method: GET, Request Url: http://localhost:8080/kie-server/services/rest/server/containers

<?xml version="1.0" encoding="UTF-8" standalone="yes"?>

<response type="SUCCESS" msg="List of created containers">
	
	<kie-containers>
	
		<kie-container container-id="REDEMPTION" status="STARTED">
			<release-id>
				<artifact-id>redemption-rules</artifact-id>
				<group-id>com.aexp.earn</group-id>
				<version>LATEST</version>
			</release-id>
			<resolved-release-id>
				<artifact-id>redemption-rules</artifact-id>
				<group-id>com.aexp.earn</group-id>
				<version>20151121231652</version>
			</resolved-release-id>
			<scanner poll-interval="10000" status="STARTED"/>
		</kie-container>
		
		<kie-container container-id="REDEMPTION-20151121231454" status="STARTED">
			<release-id>
				<artifact-id>redemption-rules</artifact-id>
				<group-id>com.aexp.earn</group-id>
				<version>20151121231454</version>
			</release-id>
			<resolved-release-id>
				<artifact-id>redemption-rules</artifact-id>
				<group-id>com.aexp.earn</group-id>
				<version>20151121231454</version>
			</resolved-release-id>
		</kie-container>
		
	</kie-containers>
	
</response>
 
--- Request Method: POST, Request Url: http://localhost:8080/kie-server/services/rest/server/containers/REDEMPTION-20151121231454
--- Additional Headers - Content-Type : application/xml ; Authorization: admin / ●●●●●●●●●●
 
<kie-container container-id="REDEMPTION-20151121231454" status="RUNNING">
	<release-id>
		<artifact-id>redemption-rules</artifact-id>
        <group-id>com.aexp.earn</group-id>
        <version>20151121231454</version>
	</release-id>
</kie-container>

--- Mappings

<mapping>

	<class name="com.redhat.web.monitor.domain.Response">
		<map-to xml="response" />
		<field name="type" type="string">
			<bind-xml name="type" node="attribute" />
		</field>
		<field name="msg" type="string">
			<bind-xml name="msg" node="attribute" />
		</field>
		<field name="kie_containers" type="com.redhat.web.monitor.domain.KieContainers">
			<bind-xml name="kie-containers" />
		</field>
	</class>

		<class name="com.redhat.web.monitor.domain.KieContainers">
			<map-to xml="kie-containers" />
			<field name="kie_container" type="com.redhat.web.monitor.domain.KieContainer" collection="arraylist">
				<bind-xml name="kie-container" />
			</field>
		</class>
			
			<class name="com.redhat.web.monitor.domain.KieContainer">
				<map-to xml="kie-container" />
				<field name="container_id" type="string">
					<bind-xml name="container-id" node="attribute" />
				</field>
				<field name="status" type="string">
					<bind-xml name="status" node="attribute" />
				</field>
				<field name="release_id" type="com.redhat.web.monitor.domain.ReleaseId">
					<bind-xml name="release-id" />
				</field>
				<field name="release_id" type="com.redhat.web.monitor.domain.ReleaseId">
					<bind-xml name="release-id" />
				</field>
				<field name="resolved_release_id" type="com.redhat.web.monitor.domain.ResolvedReleaseId">
					<bind-xml name="release-id" />
				</field>
				<field name="kieScannerXML" type="com.redhat.web.monitor.domain.KieScannerXML">
					<bind-xml name="scanner" />
				</field>
			</class>

				<class name="com.redhat.web.monitor.domain.ReleaseId">
					<map-to xml="release-id" />
					<field name="artifact_id" type="string">
						<bind-xml name="artifact-id" node="element" />
					</field>
					<field name="group_id" type="string">
						<bind-xml name="group-id" node="element" />
					</field>
					<field name="version" type="string">
						<bind-xml name="version" node="element" />
					</field>
				</class>	
				<class name="com.redhat.web.monitor.domain.ResolvedReleaseId">
					<map-to xml="resolved-release-id" />
					<field name="artifact_id" type="string">
						<bind-xml name="artifact-id" node="element" />
					</field>
					<field name="group_id" type="string">
						<bind-xml name="group-id" node="element" />
					</field>
					<field name="version" type="string">
						<bind-xml name="version" node="element" />
					</field>
				</class>	
				<class name="com.redhat.web.monitor.domain.KieScannerXML">
					<map-to xml="scanner" />
					<field name="poll_interval" type="string">
						<bind-xml name="poll-interval" node="attribute" />
					</field>
					<field name="status" type="string">
						<bind-xml name="status" node="attribute" />
					</field>
				</class>	

</mapping>