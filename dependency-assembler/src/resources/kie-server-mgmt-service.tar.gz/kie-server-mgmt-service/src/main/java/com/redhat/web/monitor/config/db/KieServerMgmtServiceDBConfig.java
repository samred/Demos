package com.redhat.web.monitor.config.db;

import java.util.Map;

import com.redhat.web.monitor.config.api.KieServerMgmtServiceConfig;

public class KieServerMgmtServiceDBConfig implements KieServerMgmtServiceConfig {

	@Override
	public Map<String, String> getConfigs() {
		// TODO Auto-generated method stub
		return null;
	}

}
