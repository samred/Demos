package com.redhat.web.monitor.domain;

public class KieScannerXML {

	private String poll_interval;
	private String status;
	
	public String getPoll_interval() {
		return poll_interval;
	}
	public void setPoll_interval(String poll_interval) {
		this.poll_interval = poll_interval;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	@Override
	public String toString() {
		return "KieScannerXML [poll_interval=" + poll_interval + ", status="
				+ status + "]";
	}

	
}