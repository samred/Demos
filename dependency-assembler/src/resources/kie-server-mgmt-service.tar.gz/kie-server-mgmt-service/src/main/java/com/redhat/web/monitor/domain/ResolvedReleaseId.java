package com.redhat.web.monitor.domain;

public class ResolvedReleaseId {

	private String artifact_id;
	private String group_id;
	private String version;
	
	public String getArtifact_id() {
		return artifact_id;
	}
	public void setArtifact_id(String artifact_id) {
		this.artifact_id = artifact_id;
	}
	public String getGroup_id() {
		return group_id;
	}
	public void setGroup_id(String group_id) {
		this.group_id = group_id;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	@Override
	public String toString() {
		return "ResolvedReleaseId [artifact_id=" + artifact_id + ", group_id="
				+ group_id + ", version=" + version + "]";
	}

	
}