package com.redhat.web.monitor.domain;


public class KieResponseXML {

	private String response;
	private String type;
	private String msg;
	
	private KieContainers kie_containers;

	public String getResponse() {
		return response;
	}

	public void setResponse(String response) {
		this.response = response;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public KieContainers getKie_containers() {
		return kie_containers;
	}

	public void setKie_containers(KieContainers kie_containers) {
		this.kie_containers = kie_containers;
	}

	@Override
	public String toString() {
		return "Response [response=" + response + ", type=" + type + ", msg="
				+ msg + ", kie_containers=" + kie_containers + "]";
	}
	
}