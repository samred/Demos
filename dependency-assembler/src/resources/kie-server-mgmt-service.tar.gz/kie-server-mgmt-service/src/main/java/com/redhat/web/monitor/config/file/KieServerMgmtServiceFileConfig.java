package com.redhat.web.monitor.config.file;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Value;

import com.redhat.web.monitor.config.KieServerMgmtServiceConfigurations;
import com.redhat.web.monitor.config.api.KieServerMgmtServiceConfig;

public class KieServerMgmtServiceFileConfig implements KieServerMgmtServiceConfig {
	
	Logger logger = Logger.getLogger(KieServerMgmtServiceFileConfig.class.getName());
	
	/** SITEURL=http://www.google.com, http://www.yahoo.com */
	@Value("${SITEURL}")
	private String siteUrl;

	/** SITENAME=http://www.google.com, http://www.yahoo.com */
	@Value("${SITENAME}")
	private String siteName;

	private Map<String, String> siteConfigs;
	
	@Override
	public Map<String, String> getConfigs() throws Exception {
		
		if (siteConfigs == null || siteConfigs.isEmpty()) {
	
			List<KieServerMgmtServiceConfigurations> kieServerMgmtServiceConfigurationsList = 
					new ArrayList<KieServerMgmtServiceConfigurations>(Arrays.asList(KieServerMgmtServiceConfigurations.values()));		
	
			List<String> siteNameList = null;
			List<String> siteUrlList = null;
			
			siteConfigs = new HashMap<String, String>();
			
			for (KieServerMgmtServiceConfigurations config : kieServerMgmtServiceConfigurationsList) {
				
												
				if ( KieServerMgmtServiceFileConfig.SITENAME.equals(config.name()) ) {
					/*
					logger.log(Level.INFO, "------------------------------ TEST - 12  ------------------------------");
					logger.log(Level.INFO, "KieServerMgmtServiceFileConfig.SITENAME: " + KieServerMgmtServiceFileConfig.SITENAME);
					logger.log(Level.INFO, "config.name(): " + config.name() + ", config.toString(): " + config.toString());
					logger.log(Level.INFO, "------------------------------ TEST - 12  ------------------------------");
					*/
					siteNameList = new ArrayList<String>( Arrays.asList ( readConfigs(config).split(",") ) );
				} else if ( KieServerMgmtServiceFileConfig.SITEURL.equals(config.name()) ) {
					/*
					logger.log(Level.INFO, "------------------------------ TEST - 11  ------------------------------");
					logger.log(Level.INFO, "KieServerMgmtServiceFileConfig.SITEURL: " + KieServerMgmtServiceFileConfig.SITEURL);
					logger.log(Level.INFO, "config.name(): " + config.name() + ", config.toString(): " + config.toString());
					logger.log(Level.INFO, "------------------------------ TEST - 11  ------------------------------");
					*/
					siteUrlList = new ArrayList<String>( Arrays.asList ( readConfigs(config).split(",") ) );
				}
			}
			
			// join the 2 list
			for (int i = 0; i < siteNameList.size(); i++) {
				logger.log(Level.INFO, "------------------------------ TEST - 11  ------------------------------");
				logger.log(Level.INFO, "siteNameList.get(i): -" + siteNameList.get(i) + "-, siteUrlList.get(i): -" + siteUrlList.get(i) + "-");
				logger.log(Level.INFO, "------------------------------ TEST - 11  ------------------------------");
				siteConfigs.put(siteNameList.get(i).trim(), siteUrlList.get(i).trim());
			}
			
		}
			
		return siteConfigs;
	}

	private String readConfigs(
			KieServerMgmtServiceConfigurations kieServerMgmtServiceConfigurations) throws Exception {
		
		String configValue = null;
		
		if ( !KieServerMgmtServiceConfigurations.exists(kieServerMgmtServiceConfigurations.name())) {
			logger.log(Level.INFO, "Invalid Configuration Requested:" + kieServerMgmtServiceConfigurations.name());
			throw new Exception ("Invalid Configuration Requested: " + kieServerMgmtServiceConfigurations.name());
		} else if (KieServerMgmtServiceConfigurations.SITEURL.equals(kieServerMgmtServiceConfigurations)) {
			if (siteUrl == null) {
				logger.log(Level.INFO, "Invalid Configuration SITEURL is null in the file.");
			} else {
				configValue = siteUrl;
			}
		} else if (KieServerMgmtServiceConfigurations.SITENAME.equals(kieServerMgmtServiceConfigurations)) {
			if (siteName == null) {
				logger.log(Level.INFO, "Invalid Configuration SITENAME is null in the file.");
			} else {
				configValue = siteName;
			}
		}
		
		/*
		logger.log(Level.INFO, "------------------------------ TEST - 10  ------------------------------");
		logger.log(Level.INFO, "Configuration value:" + configValue);
		logger.log(Level.INFO, "------------------------------ TEST - 10 ------------------------------");
		*/
		return configValue;
	}

}
