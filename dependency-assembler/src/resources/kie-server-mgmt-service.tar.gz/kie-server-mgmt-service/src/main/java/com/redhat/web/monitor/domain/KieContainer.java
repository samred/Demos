package com.redhat.web.monitor.domain;

public class KieContainer {

	private String container_id;
	private String status;
	private ReleaseId release_id;
	private ResolvedReleaseId resolved_release_id;
	private KieScannerXML kieScannerXML;
	
	public String getContainer_id() {
		return container_id;
	}
	public void setContainer_id(String container_id) {
		this.container_id = container_id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public ReleaseId getRelease_id() {
		return release_id;
	}
	public void setRelease_id(ReleaseId release_id) {
		this.release_id = release_id;
	}
	public ResolvedReleaseId getResolved_release_id() {
		return resolved_release_id;
	}
	public void setResolved_release_id(ResolvedReleaseId resolved_release_id) {
		this.resolved_release_id = resolved_release_id;
	}
	public KieScannerXML getKieScannerXML() {
		return kieScannerXML;
	}
	public void setKieScannerXML(KieScannerXML kieScannerXML) {
		this.kieScannerXML = kieScannerXML;
	}
	
	@Override
	public String toString() {
		return "KieContainer [container_id=" + container_id + ", status="
				+ status + ", release_id=" + release_id
				+ ", resolved_release_id=" + resolved_release_id
				+ ", kieScannerXML=" + kieScannerXML + "]";
	}
	
}