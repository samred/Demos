package com.redhat.web.monitor.config.api;

import java.util.Map;

public interface KieServerMgmtServiceConfig {

	public static final String SITENAME="SITENAME";
	public static final String SITEURL="SITEURL";
	
	Map<String, String> getConfigs() throws Exception;

}
