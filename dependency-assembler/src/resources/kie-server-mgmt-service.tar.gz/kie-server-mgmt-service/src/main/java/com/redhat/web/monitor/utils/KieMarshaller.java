package com.redhat.web.monitor.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.springframework.oxm.Marshaller;
import org.springframework.oxm.Unmarshaller;

import com.redhat.web.monitor.domain.KieContainer;
import com.redhat.web.monitor.domain.KieResponseXML;

public class KieMarshaller {

    private Marshaller marshaller;
    private Unmarshaller unmarshaller;
 
    public void setMarshaller(Marshaller marshaller) {
        this.marshaller = marshaller;
    }
 
    public void setUnmarshaller(Unmarshaller unmarshaller) {
        this.unmarshaller = unmarshaller;
    }
 
    /**
     * Java to xml
     * @throws IOException
     */
    public String getKieContainerXML(KieContainer kieContainer) throws IOException {
        ByteArrayOutputStream os = null;
        String kieContainerXML = null;
        try {
            os = new ByteArrayOutputStream();
            this.marshaller.marshal(kieContainer, new StreamResult(os));
            kieContainerXML = os.toString();
        } finally {
            if (os != null) {
                os.close();
            }
        }
        
        return kieContainerXML;
    }
    
    /**
     * Java to xml
     * @throws IOException
     */
    public KieResponseXML getKieResponseObj(String kieResponseXMLString) throws IOException {
    	KieResponseXML kieResponseXML = null;
		// convert String into InputStream
		InputStream is = new ByteArrayInputStream(kieResponseXMLString.getBytes());
		try {
			kieResponseXML = (KieResponseXML) this.unmarshaller.unmarshal(new StreamSource(is));
			System.out.println("KieResponseXML loaded from xml : " + kieResponseXML);
		} finally {
			if (is != null) {
				is.close();
			}
		}
		return kieResponseXML;
    }    
    
}
