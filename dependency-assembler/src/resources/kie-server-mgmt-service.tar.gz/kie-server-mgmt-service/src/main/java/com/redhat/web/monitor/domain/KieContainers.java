package com.redhat.web.monitor.domain;

import java.util.List;

public class KieContainers {

	private List<KieContainer> kie_container;

	public List<KieContainer> getKie_container() {
		return kie_container;
	}

	public void setKie_container(List<KieContainer> kie_container) {
		this.kie_container = kie_container;
	}

	@Override
	public String toString() {
		return "KieContainers [kie_container=" + kie_container + "]";
	}

	
}