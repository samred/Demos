package com.redhat.web.monitor.controller;

import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;

import com.redhat.web.monitor.config.api.KieServerMgmtServiceConfig;
import com.redhat.web.monitor.domain.KieContainer;
import com.redhat.web.monitor.domain.KieResponseXML;
import com.redhat.web.monitor.domain.ReleaseId;
import com.redhat.web.monitor.utils.KieMarshaller;

@Controller
public class KieServerMgmtServiceController {

	Logger logger = Logger.getLogger(KieServerMgmtServiceController.class
			.getName());

	@Autowired
	KieServerMgmtServiceConfig kieServerMgmtServiceConfig;

	@Autowired
	KieMarshaller converterBean;

	@Autowired
	protected RestTemplate restTemplate;

	@RequestMapping(value = "/monitor", method = RequestMethod.GET)
	@ResponseBody
	public String monitor() {
		
		initContainers() ;

		if (checkStatus()) {
			return "Success";
		} else {
			return "Failure";
		}
	}

	@RequestMapping(value = "/status", method = RequestMethod.GET)
	@ResponseBody
	public String status() {
		return "Failure";
	}

	private boolean initContainers() {

		try {
			String plainCreds = "admin:jboss#1234";
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);
			
			ReleaseId release_id = new ReleaseId();
			release_id.setArtifact_id("test");
			release_id.setGroup_id("com.rhc");
			release_id.setVersion("1448602158560");
			
			KieContainer kieContainer = new KieContainer();
			kieContainer.setContainer_id("TEST");
			kieContainer.setStatus("RUNNING");
			kieContainer.setRelease_id(release_id);
			
			String requestBody = converterBean.getKieContainerXML(kieContainer);
			//Remove prolog from RequestBody
			// requestBody = requestBody.substring(requestBody.indexOf("<kie-container"));
			
	        logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
			logger.log(Level.INFO, "requestBody : " + requestBody  );
			logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");
	
			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64Creds);
			headers.setContentType(MediaType.APPLICATION_XML);
			
			String url = kieServerMgmtServiceConfig.getConfigs().get("TEST") + "/TEST";
	
			HttpEntity<String> request = new HttpEntity<String>(requestBody, headers);
			ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.PUT, request, String.class);
			HttpStatus status = response.getStatusCode();
			String result = response.getBody();			
			
	        logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
			logger.log(Level.INFO, "result : " + result + ", status : " + status.value() );
			logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;

	}

	private boolean checkStatus() {

		/*
		logger.log(Level.INFO, "------------------------------ TEST - 1 ------------------------------");
		*/
		
		try {
			/*
			logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
			logger.log(Level.INFO, "KieServerMgmtServiceFileConfig : " + kieServerMgmtServiceConfig.getConfigs());
			logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");
			*/
			
		    // Return view newstemplate. Via resolver the view
	        // will be mapped to /WEB-INF/jsp/newstemplate.jsp
			// String url = "http://search.yahooapis.com/NewsSearchService/V1/newsSearch?appid={appid}&query={query}&results={results}&language={language}";
			

	        logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
	        Set<Map.Entry<String, String>> entrySet = kieServerMgmtServiceConfig.getConfigs().entrySet();
	        for (Map.Entry<String, String> entry : entrySet) {
				logger.log(Level.INFO, "entry.getKey() :-" + entry.getKey() +  "-, entry.getValue() : -" + entry.getValue() + "-" );
	        }
			logger.log(Level.INFO, "--- BEGIN");
			logger.log(Level.INFO, "kieServerMgmtServiceConfig.getConfigs().get(\"TEST" + kieServerMgmtServiceConfig.getConfigs().get("TEST") + "-" );
			logger.log(Level.INFO, "--- END");
			logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");

			String plainCreds = "admin:jboss#1234";
			byte[] plainCredsBytes = plainCreds.getBytes();
			byte[] base64CredsBytes = Base64.encodeBase64(plainCredsBytes);
			String base64Creds = new String(base64CredsBytes);

			HttpHeaders headers = new HttpHeaders();
			headers.add("Authorization", "Basic " + base64Creds);

			HttpEntity<String> request = new HttpEntity<String>(headers);
			ResponseEntity<String> response = restTemplate.exchange(kieServerMgmtServiceConfig.getConfigs().get("TEST"), HttpMethod.GET, request, String.class);
			HttpStatus status = response.getStatusCode();
			String result = response.getBody();			
			
			// // ResponseEntity<String> response = restTemplate.postForEntity(kieServerMgmtServiceConfig.getConfigs().get("Yahoo"), null, String.class);
			// ResponseEntity<String> response = restTemplate.getForEntity(kieServerMgmtServiceConfig.getConfigs().get("TEST"), String.class);
			// HttpStatus status = response.getStatusCode();
			// String result = response.getBody();			
	        // String result = restTemplate.getForObject(kieServerMgmtServiceConfig.getConfigs().get("YAHOO"), String.class, "");
			
	        logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
			logger.log(Level.INFO, "result : " + result + ", status : " + status.value() );
			logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");

			KieResponseXML kieResponseXML = converterBean.getKieResponseObj(result);
			
			if (kieResponseXML.getKie_containers().getKie_container() != null && kieResponseXML.getKie_containers().getKie_container().size() > 0) {
		        logger.log(Level.INFO, "------------------------------ TEST - 2 ------------------------------");
				logger.log(Level.INFO, "kieResponseXML.getMsg() : " + kieResponseXML.getMsg() + ", kieResponseXML.getType() : " + kieResponseXML.getType() 
										+ "kieResponseXML.getKie_containers().getKie_container() : " + (kieResponseXML.getKie_containers() == null ? "Null" : "Not Null")
										+ ", kieResponseXML.getKie_containers().getKie_container().size() : " + kieResponseXML.getKie_containers().getKie_container().size() );
				logger.log(Level.INFO, "------------------------------ TEST - 3 ------------------------------");
			}

	        // return result;
			// return kieServerMgmtServiceConfig.getConfigs().toString();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return true;

	}

}

