package com.redhat.web.monitor.config;

public enum KieServerMgmtServiceConfigurations {

	/** URLs */
	SITEURL,
	/** Site Names */
	SITENAME;
	
	public static boolean exists(String s) {
		if (s.equals("SITEURL") || s.equals("SITENAME"))
			return true;
		
		return false;
	}
}
